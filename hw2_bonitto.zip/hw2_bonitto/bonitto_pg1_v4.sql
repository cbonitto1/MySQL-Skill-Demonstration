/*** Welcome to DA Bootcamp Homework 2. 
	Write SQL Statements beneath the PROBLEMS to satisfy all criteria.
	Update all instances of "lastname" to be your last name, lower case. This includes the Schema and filenames.
	Your submission must be a zip file including all 4 files 

	Your homework will be graded by executing each statement one-by-one in the order 
	in which they occur. There should be no Errors; Warnings are permissible when using IF EXISTS/IF NOT EXISTS.
***/


/*** Initial Setup - only change lastname to your last name ***/ 
Select @@autocommit; -- 1 by default, all commands COMMIT immediately (no ROLLBACK)
Set @@autocommit = 0; -- ROLLBACK may be used to reverse DML changes not yet COMMIT.
Select @@SQL_SAFE_UPDATES; -- 1 by default
Set @@SQL_SAFE_UPDATES = 0; -- Lifts Warning on DELETE


DROP SCHEMA IF EXISTS da_bootcamp_bonitto; 
CREATE SCHEMA IF NOT EXISTS da_bootcamp_bonitto;
USE da_bootcamp_bonitto;

/*** PROBLEM 1 - Data Definition Language ***/
/* 
	There are 5 main DDL commands: CREATE, DROP, ALTER, TRUNCATE, and RENAME.
    You are tasked with creating a simple table, altering it, renaming it, selecting, then dropping it.
	1. Create a new table 'animals' with an ID column (type INT) and 2 additional columns (any name and datatype).
    2. Add a new column to the table, then DROP one of the other columns (other than ID).
    3. Rename the table to 'zoo_animals'
    4. Select all records from the (empty) zoo_animals table
    5. Drop the table - actually, to be on the safe side, use the "if exists" condition to 
		drop animals if it exists, and drop zoo_animals if it exists.
*/
DROP TABLE IF EXISTS zoo_animals; # personally added to test code
DROP TABLE IF EXISTS animals;


CREATE TABLE IF NOT EXISTS animals (
animals_ID MEDIUMINT, # Data type was used to reflect a real world use case, and optimized for memory
animal_name VARCHAR(20),
animal_habitat VARCHAR(10)
);
ALTER TABLE animals
ADD COLUMN animal_food VARCHAR(20),
DROP COLUMN animal_habitat;

ALTER TABLE animals
RENAME TO zoo_animals;

SELECT * FROM zoo_animals;

DROP TABLE IF EXISTS zoo_animals;

DROP TABLE IF EXISTS animals;




/*** PROBLEM 2 - Data Manipulation Language ***/
/* 
	DML Statements make changes to the contents of tables - Insert, Delete, Update
    You will load the raw data provided, and using TCL commands ROLLBACK and COMMIT to make and undo changes.
    1. Create table item_details using field names (item_id, item_price, item_description), using sensible data types.
    2. INSERT all raw data provided into item_detail. COMMIT the change.
    3. SELECT * to confirm all 5 rows are present.
    4. DELETE all records for which the item price is greater-than-or-equal-to 2. 
    5. SELECT * to confirm deletions. ROLLBACK the change, and SELECT * once again to confirm 5 original rows present.
    6. Ah, the price for Apples was wrong. UPDATE that record to price 6 instead of 60.
    7. The price of Avocados and Broccoli have doubled. UPDATE those records to reflect the price doubling.
    8. SELECT * to confirm the records are correct. COMMIT. Table item_details is ready for use in PROBLEM 3.
    9. SUGGESTION: To make debugging PROBLEM 3 easier, 
		you may wish to make note of item_details record values as of Step 8, then 
        TRUNCATE item_details and INSERT records to match those recorded values to have a reliable starting point.

Raw data provided: 
('itm001',2,'Avocado (ind)'),
('itm002',60,'Apple Bag'),
('itm003',0.5,'Lemons (ind)'),
('itm004',2,'Banana (lb)'),
('itm005',3,'Broccoli (head)')
*/

DROP TABLE IF EXISTS item_details;

CREATE TABLE item_details (
item_id VARCHAR(20), 
item_price TINYINT, 
item_description VARCHAR(20)
);
INSERT INTO item_details (item_id, item_price, item_description) 
VALUES 
('itm001',2,'Avocado (ind)'),
('itm002',60,'Apple Bag'),
('itm003',0.5,'Lemons (ind)'),
('itm004',2,'Banana (lb)'),
('itm005',3,'Broccoli (head)');

COMMIT;

SELECT * FROM item_details;

DELETE FROM item_details WHERE item_price >= 2;

SELECT * FROM item_details;
ROLLBACK;
SELECT * FROM item_details;

UPDATE item_details
SET item_price = 6
WHERE item_description = 'Apple Bag'; # As long as item_description remains constant,these solutions remain scalable for each fruit

UPDATE item_details
SET item_price = 4
WHERE item_description = 'Avocado (ind)'; # if fruit type did not matter then item_price could be used instead

UPDATE item_details
SET item_price = 6
WHERE item_description = 'Broccoli (head)';

SELECT * FROM item_details;
COMMIT;

/*** PROBLEM 3 - Data Querying Clauses and Joins ***/
/* 
	Big data! Well, relatively big. You will create table sales_orders and get to work analyzing. 
    You're encouraged to experiment with using TEMPORARY tables in your analysis, but your final queries must not 
    include them - you must only submit queries using the base sales_orders and item_details tables.
    1. Create table sales_orders with 5 columns: 
		a. record_id, a Big Integer Primary Key that auto-increments with each new record added.
        b. order_no, another Big Integer that cannot be NULL
        c. order_date, DATE
        d. item_id, formatted to match item_details.item_id from PROBLEM 2.
        e. quantity, Big Integer
	2. Load sales_orders with the raw data provided in pg2. You may write and leave the entire INSERT statement there.
    
    You will then write SQL queries answering the following (include the full question as a comment above your query). 
    It's always assumed that sales_orders joins item_details on item_id. 
    Line_item_total is the product of quantity and item_price.
    Order_Total is the sum of line_item_totals for a given Order_no.
    3. What is the total number of records in sales_orders? 
    4. What is the total number of records of sales_orders INNER JOIN item_details? LEFT JOIN?
    5. Return the order_no, order_date, and the order_total for the top 10 orders in August in descending order.
    6. Return the order_no, order_date, and the total quantity for orders HAVING a total quantity greater than 10.
    7. Create stored procedure "total_sales_on_date" that returns total sales (in $) given a date.
    
*/

DROP TABLE IF EXISTS sales_orders;

CREATE TABLE sales_orders (
record_id BIGINT PRIMARY KEY AUTO_INCREMENT,
order_no MEDIUMINT NOT NULL,
order_date DATE,
item_id VARCHAR(20), 
quantity MEDIUMINT
); # Data types were adjusted to optimize memory, but their is still room for improvement

/*3. What is the total number of records in sales_orders?*/
SELECT COUNT(record_id)
FROM sales_orders;

/*4. What is the total number of records of sales_orders INNER JOIN item_details? LEFT JOIN?*/
SELECT COUNT(s.item_id), i.item_id #casted/abbreviated for enhanced readability
FROM sales_orders s
INNER JOIN item_details i
  ON s.item_id = i.item_id
ORDER BY item_id DESC;

SELECT COUNT(s.record_id), i.item_id 
FROM sales_orders s
LEFT JOIN item_details i
  ON s.item_id = i.item_id
ORDER BY item_id DESC;

/*5. Return the order_no, order_date, and the order_total for the top 10 orders in August in descending order.*/
SELECT s.order_no, s.order_date, SUM(i.item_price * s.quantity) AS order_total
FROM sales_orders s
INNER JOIN item_details i # A Natural Join would have sufficed too but it's always better to be explicit when dealing with big data to improve computational efficiency
  ON s.item_id = i.item_id
GROUP BY order_no
HAVING order_date BETWEEN '2019-08-01' AND '2019-08-31'
ORDER BY order_total DESC
LIMIT 10;

/*6. Return the order_no, order_date, and the total quantity for orders HAVING a total quantity greater than 10.*/
SELECT order_no, order_date, SUM(quantity) AS total_quantity
FROM sales_orders
GROUP BY order_no
HAVING total_quantity > 10
ORDER BY total_quantity ASC;

/*7. Create stored procedure "total_sales_on_date" that returns total sales (in $) given a date.*/
DROP PROCEDURE IF EXISTS total_sales_on_date; # personally added to test code

DELIMITER //
CREATE PROCEDURE total_sales_on_date(
   IN given_date DATE # date inputted by user
 )
BEGIN
  SELECT SUM(item_price * quantity) AS "Total Sales (in $)",
   order_date AS "Given Date"
  FROM sales_orders s 
  NATURAL JOIN item_details i #finds columns in common and joins there
  WHERE s.order_date = given_date
  GROUP BY s.order_date;
END //

DELIMITER ;

CALL total_sales_on_date ('2019-07-23');




/*** PROBLEM 4 - Expanding a Dimension Table ***/
/*
	On the lastname_pg4 page you are provided the beginnings of a Date Dimension table named date_dim.
    
    1. You must create a list in Excel of all dates from 7/1/2019 to 12/31/2019, 
    in order to create the INSERT statement. Comment below with a description of what EXCEL
    functions you used to create the data, copy-pasting the entire functions including the = sign
    
    At first, I created one date, then I highlighted the column and used the fill button to create the right range of dates.Then, I used custom formatting
    to insert quotes and parentheses.Using a similar method, I created an appropriate range of date values, and converted it into the proper date format
    using the TEXT() function. Then I concated parentheses and quotes and applied that to the entire column.
    
    
    2. You must then UPDATE date_dim to populate all the columns. You can find date conversion
    functions for MySQL online.
    
    Write a query joining date_dim onto sales_orders & item_details to answer the questions: 
    3. Sales ($) for each item_description broken down by day of the week.
		Columns should be: Item Description, Day of Week, Sales Total
    4. Total Quantity Sold by Product by Quarter. Columns should be: Item_ID, Quarter YYYYMM, Total Quantity
*/

#1. Comment here with what Excel functions you used to generate the test dataset.
    /*
    
    At first, I created one date, then I highlighted the column and used the fill button to create the right range of dates.Then, I used custom formatting
    to insert quotes and parentheses.Using a similar method, I created an appropriate range of date values, and converted it into the proper date format 
    using the TEXT() function. Then I concated parentheses and quotes and applied that to the entire column.*/

#2. Occurs entirely on lastname_pg4


#3. Please write query below. 
SELECT * FROM date_dim d, sales_orders s, item_details i; # to confirm that the values are there
SELECT item_description AS "Item Description", TheDayOfWeek AS "Day of Week", SUM(quantity * item_price) AS "Sales Total" # changed it to TheDayOfWeekName for better readability
FROM sales_orders s
NATURAL JOIN item_details i # An explicit inner join would be more computationally efficient, but I just wanted to show off :)
LEFT JOIN date_dim d
  ON s.order_date = d.TheDate
GROUP BY TheDayOfWeek, item_description
ORDER BY item_description, TheDayOfWeek ASC;
#4. Please write query below.

SELECT s.item_id AS "Item ID", YYYYQQ AS "Quarter YYYYQQ", SUM(quantity) AS "Total Quantity"
FROM sales_orders s
NATURAL JOIN item_details i 
LEFT JOIN date_dim d
  ON s.order_date = d.TheDate
GROUP BY YYYYQQ, s.item_id
ORDER BY YYYYQQ, s.item_id;

# Grader Note: I did not have much experience with SQL with this assignment, but I'm proud to say that I learned alot. Thank You!

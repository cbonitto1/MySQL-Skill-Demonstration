#page 3 is reserved for SQL experimentation on Problem 3. 
#You're encouraged to experiment here but your final (tidy) answers must be on page 1. 
#TEMPORARY TABLEs are fun because you can query directly into them without constucting them first.
#Great for exploratory analysis.

Use da_bootcamp_lastname;

DROP TEMPORARY TABLE IF EXISTS sales_data_all;

CREATE TEMPORARY TABLE sales_data_all
#SELECT ...

SELECT count(*) from sales_data_all;



#Provide any other queries you used and wish to share. This is optional but hopefully valuable.
#Problem 3 question 7

DELIMITER //
CREATE PROCEDURE total_sales_on_date(
   IN given_date DATE # date inputted by user
 )
BEGIN
  SELECT SUM(i.item_price * s.quantity) AS total_sales,
   order_date
  FROM sales_orders s # abbreviation makes code easier to read/process
  INNER JOIN item_details i
    ON i.item_id = s.item_id
  GROUP BY s.order_date
  HAVING s.order_date = given_date;
END //

DELIMITER ;

CALL total_sales_on_date ('2019-07-23');



#Problem 4 question 4
SELECT i.item_id, YYYYQQ, SUM(quantity) AS total_quantity
FROM sales_orders s
NATURAL JOIN item_details i # NATURAL Join just to show off :) A regular join-- like the previous code-- on item_id would have sufficed.
LEFT JOIN date_dim d
  ON s.order_date = d.TheDate
GROUP BY YYYYQQ;














